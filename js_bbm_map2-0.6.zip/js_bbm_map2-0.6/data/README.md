R0_mn:

Original Data in R0_2019.csv and R0_2023.csv
The Data for the years in between are copies.